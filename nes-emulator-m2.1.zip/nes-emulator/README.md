# NES Emulator — by ByKhalilXmodz

Status: **Milestone 2 (CPU) implemented; nestest validation prepared but NOT yet run.** No PPU, APU, bus or cartridge yet, so no game can run.
APK: **not built yet** (the Android build has never been run; see "Build status").

## Milestone 2 — Ricoh 2A03 / 6502 CPU (`app/src/main/cpp/cpu/`)
- Registers A, X, Y, PC, SP, P; all 13 addressing modes; **151 official opcodes**, table-driven.
- Cycle counts per official opcode, +1 for page crossing on reads (abs,X / abs,Y / (zp),Y),
  branch +1 taken / +2 taken across a page. Stores and read-modify-write use fixed counts.
- Stack ops, BRK, RTI, JSR/RTS, reset (SP=0xFD, P=0x24, PC=[$FFFC], 7 cycles).
- NMI (edge, serviced before next instruction), IRQ (level, masked by I), 7 cycles each.
- Memory access through `ReadFn`/`WriteFn` callbacks + `void* ctx`, ready for the future bus.
- `stall(n)` adds cycles to the next `step()` (for OAM DMA). The DMA itself is not implemented.
- Decimal flag can be set but has no effect on ADC/SBC (as on the 2A03). JMP (ind) page-wrap bug emulated.

### Not supported / known inaccuracies
- **Unofficial opcodes (105 values) are NOT implemented.** They run as a 1-byte, 2-cycle NOP and
  increment `Cpu6502::illegalCount` (`lastIllegalOpcode` records the value). Games that use them will misbehave.
- No dummy reads/writes (matters for some PPU/mapper register side effects), and RMW instructions write once.
- No CLI/SEI/PLP one-instruction IRQ latency, no NMI/IRQ hijacking of BRK, no interrupt polling at cycle level.
- Cycle accounting is per instruction, not per bus cycle.

### Tests (`app/src/main/cpp/tests/cpu_tests.cpp`)
Standalone, no framework: opcode table vs. hand-written official-opcode/cycle table (all 151),
every illegal opcode executes safely, load/store/transfer, ADC/SBC (carry, overflow, borrow, decimal ignored),
logic/compare/BIT, shifts/rotates/INC/DEC, all addressing modes (zero-page wrap, page-cross cycles, indirect bug),
all branch conditions and cycle cases, stack/JSR/RTS/RTI/PHP/PLP, flags, BRK/NMI/IRQ, DMA stall, a looped program.
- Last local run (g++, `-Wall -Wextra -Werror`, ASan+UBSan): **781 checks, 0 failed**.
- Limitation: tests were written by the same author as the CPU. No third-party suite (e.g. nestest) was run yet;
  that is the next validation step and needs a legally obtained copy.

Run locally: `cmake -S app/src/main/cpp/tests -B build-tests && cmake --build build-tests && ctest --test-dir build-tests`

## Build status
- Host build + tests: verified locally (x86-64 g++). The test step runs first in `.github/workflows/android.yml`.
- Android/ARMv7 build: **not verified.** No NDK, ARM compiler or network was available in my environment.
  The CPU uses only fixed-width integer types, but ARMv7 compilation under NDK clang with `-Werror` is untested.
- The Gradle wrapper jar is not committed; the workflow generates it.

## Compatibility
| Mapper | Status |
|---|---|
| all | not implemented yet |

## nestest validation (Milestone 2.1)
- `tests/nestest_runner.cpp` runs nestest in automation mode (PC=$C000, P=$24, SP=$FD, 7 cycles) and compares
  PC, A, X, Y, P, SP and cumulative cycles against `nestest.log` before every instruction.
  It stops at the first **unofficial** opcode (not implemented), so only the official-opcode portion is checked.
- **Status: NOT RUN against the real ROM/log.** My environment has no network, so I could not obtain them and
  therefore found/fixed no discrepancies. The runner is verified only by `--selftest` (5 hand-written real log lines,
  plus a deliberately corrupted line that must be detected).
- CI fetches the ROM (md5 4068f00f3db2fe783e437681fa6b419a) and log at build time and fails the job if
  either is missing or the trace differs. Both are fetch-only, never committed: licence is unclear. The download URLs
  (christopherpow/nes-test-roms `other/` and a fallback) are taken from forum/search references and are unverified.
- Run locally: `cmake -S app/src/main/cpp/tests -B build-tests -DNESTEST_ROM=/path/nestest.nes -DNESTEST_LOG=/path/nestest.log`

## CI verification added
- ARMv7 compile of the CPU core with the NDK clang (`armv7a-linux-androideabi21-clang++ -Werror`) before Gradle.
- APK check: requires `lib/armeabi-v7a/libnescore.so`, fails on any other `lib/` entry, and checks the ELF is 32-bit ARM.
- **None of this has run yet.** Android compatibility is not claimed until the Actions run passes.

package com.bykhalilxmodz.nes;

public final class EmulatorBridge {
    static { System.loadLibrary("nescore"); }
    private EmulatorBridge() {}
    public static native String nativeInfo();
}

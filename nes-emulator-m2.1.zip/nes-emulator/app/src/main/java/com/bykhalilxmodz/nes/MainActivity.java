package com.bykhalilxmodz.nes;

import android.app.Activity;
import android.graphics.Color;
import android.os.Bundle;
import android.view.Gravity;
import android.widget.LinearLayout;
import android.widget.TextView;

public class MainActivity extends Activity {
    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setGravity(Gravity.CENTER);
        root.setBackgroundColor(Color.rgb(18, 18, 22));
        root.addView(text("NES Emulator", 28, Color.WHITE));
        root.addView(text("ByKhalilXmodz", 16, Color.LTGRAY));
        root.addView(text(EmulatorBridge.nativeInfo(), 12, Color.GRAY));
        setContentView(root);
    }
    private TextView text(String s, int sp, int color) {
        TextView t = new TextView(this);
        t.setText(s); t.setTextSize(sp); t.setTextColor(color);
        t.setGravity(Gravity.CENTER); t.setPadding(24, 12, 24, 12);
        return t;
    }
}

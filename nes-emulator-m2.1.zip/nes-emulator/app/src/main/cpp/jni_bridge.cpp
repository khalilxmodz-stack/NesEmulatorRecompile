#include <jni.h>
#include <string>
#include "core/nes.h"
extern "C" JNIEXPORT jstring JNICALL
Java_com_bykhalilxmodz_nes_EmulatorBridge_nativeInfo(JNIEnv* env, jclass) {
    std::string s = std::string("Core ") + nes::coreVersion() + ", " +
                    std::to_string(nes::pointerSizeBits()) + "-bit, CPU official opcodes: " +
                    std::to_string(nes::cpuOfficialOpcodeCount());
    return env->NewStringUTF(s.c_str());
}

// nestest trace comparison (CPU only, "automation mode" at PC=$C000).
//   nestest_runner --selftest            plumbing check using hand-written log lines
//   nestest_runner <nestest.nes> <nestest.log>
// Compares PC, A, X, Y, P, SP and cumulative CPU cycles before every instruction.
// The log's disassembly, "= xx" memory annotations and PPU columns are ignored.
// The comparison stops at the first UNOFFICIAL opcode (not implemented, see README).
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <fstream>
#include <iterator>
#include <string>
#include <vector>
#include "cpu/cpu6502.h"

using nes::Cpu6502;

struct Mem {
    uint8_t ram[2048] = {};
    std::vector<uint8_t> prg;
    static uint8_t rd(void* c, uint16_t a) {
        Mem* m = static_cast<Mem*>(c);
        if (a < 0x2000) return m->ram[a & 0x7FF];
        if (a >= 0x8000 && !m->prg.empty()) return m->prg[(a - 0x8000u) % m->prg.size()];
        return 0;  // no PPU/APU/bus yet: unmapped reads return 0
    }
    static void wr(void* c, uint16_t a, uint8_t v) {
        Mem* m = static_cast<Mem*>(c);
        if (a < 0x2000) m->ram[a & 0x7FF] = v;
    }
};

struct Result { bool ok; size_t compared; std::string message; };

static bool field(const std::string& line, const char* key, int base, unsigned long long& out) {
    size_t p = line.find(key);
    if (p == std::string::npos) return false;
    out = std::strtoull(line.c_str() + p + std::strlen(key), nullptr, base);
    return true;
}

static Result runTrace(Mem& mem, const std::vector<std::string>& log) {
    Cpu6502 cpu(Mem::rd, Mem::wr, &mem);
    cpu.reset();
    cpu.pc = 0xC000; cpu.sp = 0xFD; cpu.p = 0x24; cpu.totalCycles = 7;  // nestest automation start
    Result r{true, 0, ""};
    for (size_t i = 0; i < log.size(); i++) {
        const std::string& l = log[i];
        if (l.size() < 10) continue;
        unsigned long long pc = std::strtoull(l.c_str(), nullptr, 16), a, x, y, p, sp, cyc;
        if (!field(l, " A:", 16, a) || !field(l, " X:", 16, x) || !field(l, " Y:", 16, y) ||
            !field(l, " P:", 16, p) || !field(l, " SP:", 16, sp) || !field(l, "CYC:", 10, cyc)) {
            r.ok = false; r.message = "unparseable log line " + std::to_string(i + 1) + ": " + l; return r;
        }
        uint8_t opcode = Mem::rd(&mem, cpu.pc);
        if (!Cpu6502::isOfficial(opcode)) {
            char b[160];
            std::snprintf(b, sizeof b, "stopped at first unofficial opcode %02X at PC=%04X (log line %zu)",
                          opcode, cpu.pc, i + 1);
            r.message = b; return r;
        }
        bool bad = cpu.pc != pc || cpu.a != a || cpu.x != x || cpu.y != y || cpu.p != p ||
                   cpu.sp != sp || cpu.totalCycles != cyc;
        if (bad) {
            char b[512];
            std::snprintf(b, sizeof b,
                "MISMATCH at log line %zu\n  log : %s\n  ours: PC=%04X A:%02X X:%02X Y:%02X P:%02X SP:%02X CYC:%llu",
                i + 1, l.c_str(), cpu.pc, cpu.a, cpu.x, cpu.y, cpu.p, cpu.sp,
                static_cast<unsigned long long>(cpu.totalCycles));
            r.ok = false; r.message = b; return r;
        }
        cpu.step();
        r.compared++;
    }
    r.message = "reached end of log";
    return r;
}

static int selftest() {
    // First lines of the real nestest log, reproduced by hand (cycles start at 7).
    Mem m;
    m.prg.assign(0x4000, 0);
    const uint8_t a[] = {0x4C, 0xF5, 0xC5}; std::memcpy(&m.prg[0x0000], a, sizeof a);
    const uint8_t b[] = {0xA2, 0x00, 0x86, 0x00, 0x86, 0x10, 0x86, 0x11}; std::memcpy(&m.prg[0x05F5], b, sizeof b);
    std::vector<std::string> log = {
        "C000  4C F5 C5  JMP $C5F5                       A:00 X:00 Y:00 P:24 SP:FD PPU:  0, 21 CYC:7",
        "C5F5  A2 00     LDX #$00                        A:00 X:00 Y:00 P:24 SP:FD PPU:  0, 30 CYC:10",
        "C5F7  86 00     STX $00 = 00                    A:00 X:00 Y:00 P:26 SP:FD PPU:  0, 36 CYC:12",
        "C5F9  86 10     STX $10 = 00                    A:00 X:00 Y:00 P:26 SP:FD PPU:  0, 45 CYC:15",
        "C5FB  86 11     STX $11 = 00                    A:00 X:00 Y:00 P:26 SP:FD PPU:  0, 54 CYC:18"};
    Result r = runTrace(m, log);
    std::printf("selftest positive: ok=%d compared=%zu (%s)\n", r.ok, r.compared, r.message.c_str());
    if (!r.ok || r.compared != 5) return 1;
    log[3] = log[3].replace(log[3].find("CYC:15"), 6, "CYC:16");  // must be detected
    Result bad = runTrace(m, log);
    std::printf("selftest negative: ok=%d\n", bad.ok);
    return bad.ok ? 1 : 0;
}

int main(int argc, char** argv) {
    if (argc == 2 && std::strcmp(argv[1], "--selftest") == 0) return selftest();
    if (argc != 3) { std::fprintf(stderr, "usage: %s --selftest | <nestest.nes> <nestest.log>\n", argv[0]); return 2; }
    std::ifstream rf(argv[1], std::ios::binary), lf(argv[2]);
    if (!rf || !lf) { std::fprintf(stderr, "cannot open ROM or log\n"); return 2; }
    std::vector<uint8_t> rom((std::istreambuf_iterator<char>(rf)), std::istreambuf_iterator<char>());
    if (rom.size() < 16 || std::memcmp(rom.data(), "NES\x1A", 4) != 0) { std::fprintf(stderr, "not an iNES file\n"); return 2; }
    size_t prgSize = static_cast<size_t>(rom[4]) * 0x4000, off = 16 + ((rom[6] & 4) ? 512 : 0);
    if (prgSize == 0 || off + prgSize > rom.size()) { std::fprintf(stderr, "bad PRG size\n"); return 2; }
    Mem m;
    m.prg.assign(rom.begin() + static_cast<long>(off), rom.begin() + static_cast<long>(off + prgSize));
    std::vector<std::string> log;
    for (std::string line; std::getline(lf, line);) { if (!line.empty() && line.back() == '\r') line.pop_back(); log.push_back(line); }
    Result r = runTrace(m, log);
    std::printf("log lines: %zu, compared (official opcodes only): %zu\n%s\n", log.size(), r.compared, r.message.c_str());
    std::printf("RAM $02=%02X $03=%02X (informational; nestest result codes)\n", m.ram[2], m.ram[3]);
    if (!r.ok) return 1;
    if (r.compared < 1000) { std::printf("FAIL: fewer than 1000 lines compared; log/ROM mismatch or early stop\n"); return 1; }
    std::printf("PASS: CPU trace identical for %zu instructions\n", r.compared);
    return 0;
}

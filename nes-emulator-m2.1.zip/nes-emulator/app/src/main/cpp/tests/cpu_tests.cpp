// Standalone CPU test suite (no framework). Exit code != 0 on any failure.
// NOTE: these are self-written tests; no third-party test ROM (e.g. nestest)
// has been run yet. See README.
#include <cstdio>
#include <cstring>
#include <initializer_list>
#include "cpu/cpu6502.h"

using nes::Cpu6502;

static int g_checks = 0, g_failed = 0;
#define CHECK_EQ(actual, expected)                                                   \
    do {                                                                             \
        g_checks++;                                                                  \
        unsigned long long a_ = static_cast<unsigned long long>(actual);             \
        unsigned long long e_ = static_cast<unsigned long long>(expected);           \
        if (a_ != e_) {                                                              \
            g_failed++;                                                              \
            std::printf("  FAIL %s:%d: %s = 0x%llX, expected 0x%llX\n", __FILE__,    \
                        __LINE__, #actual, a_, e_);                                  \
        }                                                                            \
    } while (0)
#define FLAG(c, f) ((((c).p & Cpu6502::f) != 0) ? 1 : 0)

struct Sys {
    uint8_t mem[65536];
    Cpu6502 cpu;
    static uint8_t rd(void* c, uint16_t a) { return static_cast<Sys*>(c)->mem[a]; }
    static void wr(void* c, uint16_t a, uint8_t v) { static_cast<Sys*>(c)->mem[a] = v; }
    Sys() : cpu(rd, wr, this) {
        std::memset(mem, 0, sizeof mem);
        mem[0xFFFC] = 0x00; mem[0xFFFD] = 0x80;  // reset -> 0x8000
        mem[0xFFFA] = 0x00; mem[0xFFFB] = 0x90;  // NMI   -> 0x9000
        mem[0xFFFE] = 0x00; mem[0xFFFF] = 0xA0;  // IRQ   -> 0xA000
        cpu.reset();
    }
    void prog(std::initializer_list<uint8_t> b, uint16_t at = 0x8000) {
        uint16_t a = at;
        for (uint8_t v : b) mem[a++] = v;
        cpu.pc = at;
    }
    unsigned step() { return cpu.step(); }
    void run(int n) { while (n--) cpu.step(); }
};

static void test_reset() {
    Sys s;
    CHECK_EQ(s.cpu.pc, 0x8000); CHECK_EQ(s.cpu.sp, 0xFD); CHECK_EQ(s.cpu.p, 0x24);
    CHECK_EQ(s.cpu.totalCycles, 7);
}

static void test_opcode_table() {
    // Independent list of the 151 official opcodes, written out by hand.
    static const uint8_t cyc[256] = {
        7,6,0,0,0,3,5,0,3,2,2,0,0,4,6,0, 2,5,0,0,0,4,6,0,2,4,0,0,0,4,7,0,
        6,6,0,0,3,3,5,0,4,2,2,0,4,4,6,0, 2,5,0,0,0,4,6,0,2,4,0,0,0,4,7,0,
        6,6,0,0,0,3,5,0,3,2,2,0,3,4,6,0, 2,5,0,0,0,4,6,0,2,4,0,0,0,4,7,0,
        6,6,0,0,0,3,5,0,4,2,2,0,5,4,6,0, 2,5,0,0,0,4,6,0,2,4,0,0,0,4,7,0,
        0,6,0,0,3,3,3,0,2,0,2,0,4,4,4,0, 2,6,0,0,4,4,4,0,2,5,2,0,0,5,0,0,
        2,6,2,0,3,3,3,0,2,2,2,0,4,4,4,0, 2,5,0,0,4,4,4,0,2,4,2,0,4,4,4,0,
        2,6,0,0,3,3,5,0,2,2,2,0,4,4,6,0, 2,5,0,0,0,4,6,0,2,4,0,0,0,4,7,0,
        2,6,0,0,3,3,5,0,2,2,2,0,4,4,6,0, 2,5,0,0,0,4,6,0,2,4,0,0,0,4,7,0};
    unsigned n = 0;
    for (int op = 0; op < 256; op++) {
        bool off = cyc[op] != 0;
        CHECK_EQ(Cpu6502::isOfficial(static_cast<uint8_t>(op)), off);
        if (off) n++;
    }
    CHECK_EQ(n, 151);
    CHECK_EQ(Cpu6502::officialOpcodeCount(), 151);
    for (int op = 0; op < 256; op++) {
        if (!cyc[op] || (op & 0x1F) == 0x10) continue;  // skip illegal and branches
        Sys s;  // X=Y=0 so no page-cross penalty; operands are zero
        s.prog({static_cast<uint8_t>(op), 0x00, 0x00});
        unsigned used = s.step();
        if (used != cyc[op]) std::printf("  opcode %02X: %u cycles, expected %u\n", op, used, cyc[op]);
        CHECK_EQ(used, cyc[op]);
    }
    for (int op = 0; op < 256; op++)  // every opcode must be executable without crashing
        if (!cyc[op]) { Sys s; s.prog({static_cast<uint8_t>(op)}); CHECK_EQ(s.step(), 2); CHECK_EQ(s.cpu.illegalCount, 1); }
}

static void test_load_store_flags() {
    Sys s;
    s.prog({0xA9, 0x00, 0xA9, 0x80, 0xA2, 0x7F, 0xA0, 0xFF});
    s.step(); CHECK_EQ(FLAG(s.cpu, FLAG_Z), 1); CHECK_EQ(FLAG(s.cpu, FLAG_N), 0);
    s.step(); CHECK_EQ(FLAG(s.cpu, FLAG_Z), 0); CHECK_EQ(FLAG(s.cpu, FLAG_N), 1); CHECK_EQ(s.cpu.a, 0x80);
    s.step(); CHECK_EQ(s.cpu.x, 0x7F); CHECK_EQ(FLAG(s.cpu, FLAG_N), 0);
    s.step(); CHECK_EQ(s.cpu.y, 0xFF); CHECK_EQ(FLAG(s.cpu, FLAG_N), 1);
    Sys t;
    t.prog({0xA9, 0x42, 0x85, 0x10, 0xA2, 0x43, 0x86, 0x11, 0xA0, 0x44, 0x84, 0x12, 0x8D, 0x34, 0x12});
    t.run(7);
    CHECK_EQ(t.mem[0x10], 0x42); CHECK_EQ(t.mem[0x11], 0x43); CHECK_EQ(t.mem[0x12], 0x44);
    CHECK_EQ(t.mem[0x1234], 0x42);
    Sys u;  // transfers
    u.prog({0xA9, 0x90, 0xAA, 0xA8, 0xA9, 0x00, 0x8A, 0x98, 0xBA, 0xA2, 0x55, 0x9A});
    u.run(3); CHECK_EQ(u.cpu.x, 0x90); CHECK_EQ(u.cpu.y, 0x90);
    u.run(2); CHECK_EQ(u.cpu.a, 0x90);  // LDA #0; TXA
    u.step(); CHECK_EQ(u.cpu.a, 0x90);  // TYA
    u.step(); CHECK_EQ(u.cpu.x, 0xFD);  // TSX
    u.run(2); CHECK_EQ(u.cpu.sp, 0x55);
}

static void test_arithmetic() {
    Sys s;  // 0x50 + 0x50 = 0xA0, signed overflow
    s.prog({0x18, 0xA9, 0x50, 0x69, 0x50});
    s.run(3);
    CHECK_EQ(s.cpu.a, 0xA0); CHECK_EQ(FLAG(s.cpu, FLAG_V), 1); CHECK_EQ(FLAG(s.cpu, FLAG_N), 1); CHECK_EQ(FLAG(s.cpu, FLAG_C), 0);
    Sys t;  // 0xFF + 1 -> 0, carry, zero
    t.prog({0x18, 0xA9, 0xFF, 0x69, 0x01});
    t.run(3);
    CHECK_EQ(t.cpu.a, 0); CHECK_EQ(FLAG(t.cpu, FLAG_C), 1); CHECK_EQ(FLAG(t.cpu, FLAG_Z), 1); CHECK_EQ(FLAG(t.cpu, FLAG_V), 0);
    Sys u;  // carry in
    u.prog({0x38, 0xA9, 0x01, 0x69, 0x01});
    u.run(3); CHECK_EQ(u.cpu.a, 3);
    Sys v;  // SBC 5-3 = 2, carry stays set
    v.prog({0x38, 0xA9, 0x05, 0xE9, 0x03});
    v.run(3); CHECK_EQ(v.cpu.a, 2); CHECK_EQ(FLAG(v.cpu, FLAG_C), 1);
    Sys w;  // SBC 0x50 - 0xB0 = 0xA0, overflow, borrow
    w.prog({0x38, 0xA9, 0x50, 0xE9, 0xB0});
    w.run(3); CHECK_EQ(w.cpu.a, 0xA0); CHECK_EQ(FLAG(w.cpu, FLAG_V), 1); CHECK_EQ(FLAG(w.cpu, FLAG_C), 0);
    Sys x;  // SBC with borrow in: 5 - 3 - 1 = 1
    x.prog({0x18, 0xA9, 0x05, 0xE9, 0x03});
    x.run(3); CHECK_EQ(x.cpu.a, 1);
    Sys d;  // decimal flag has no effect on the 2A03
    d.prog({0xF8, 0x18, 0xA9, 0x09, 0x69, 0x01});
    d.run(4); CHECK_EQ(d.cpu.a, 0x0A);
}

static void test_logic_compare() {
    Sys s;
    s.prog({0xA9, 0xF0, 0x29, 0x3C, 0x09, 0x03, 0x49, 0xFF});
    s.run(2); CHECK_EQ(s.cpu.a, 0x30);
    s.step(); CHECK_EQ(s.cpu.a, 0x33);
    s.step(); CHECK_EQ(s.cpu.a, 0xCC); CHECK_EQ(FLAG(s.cpu, FLAG_N), 1);
    Sys c;
    c.prog({0xA9, 0x40, 0xC9, 0x40, 0xC9, 0x41, 0xC9, 0x3F, 0xA2, 0x05, 0xE0, 0x05, 0xA0, 0x01, 0xC0, 0x02});
    c.run(2); CHECK_EQ(FLAG(c.cpu, FLAG_Z), 1); CHECK_EQ(FLAG(c.cpu, FLAG_C), 1);
    c.step(); CHECK_EQ(FLAG(c.cpu, FLAG_Z), 0); CHECK_EQ(FLAG(c.cpu, FLAG_C), 0); CHECK_EQ(FLAG(c.cpu, FLAG_N), 1);
    c.step(); CHECK_EQ(FLAG(c.cpu, FLAG_C), 1); CHECK_EQ(FLAG(c.cpu, FLAG_Z), 0);
    c.run(2); CHECK_EQ(FLAG(c.cpu, FLAG_Z), 1);  // CPX
    c.run(2); CHECK_EQ(FLAG(c.cpu, FLAG_C), 0);  // CPY 1 vs 2
    Sys b;  // BIT: Z from A&M, N/V from M
    b.mem[0x20] = 0xC0;
    b.prog({0xA9, 0x01, 0x24, 0x20});
    b.run(2); CHECK_EQ(FLAG(b.cpu, FLAG_Z), 1); CHECK_EQ(FLAG(b.cpu, FLAG_N), 1); CHECK_EQ(FLAG(b.cpu, FLAG_V), 1);
}

static void test_shifts_incdec() {
    Sys s;
    s.prog({0xA9, 0x81, 0x0A});  // ASL A
    s.run(2); CHECK_EQ(s.cpu.a, 0x02); CHECK_EQ(FLAG(s.cpu, FLAG_C), 1);
    Sys l;
    l.prog({0xA9, 0x01, 0x4A});  // LSR A
    l.run(2); CHECK_EQ(l.cpu.a, 0); CHECK_EQ(FLAG(l.cpu, FLAG_C), 1); CHECK_EQ(FLAG(l.cpu, FLAG_Z), 1);
    Sys r;
    r.prog({0x38, 0xA9, 0x80, 0x2A});  // SEC; ROL A -> 0x01, C=1
    r.run(3); CHECK_EQ(r.cpu.a, 0x01); CHECK_EQ(FLAG(r.cpu, FLAG_C), 1);
    Sys q;
    q.prog({0x38, 0xA9, 0x01, 0x6A});  // SEC; ROR A -> 0x80, C=1, N=1
    q.run(3); CHECK_EQ(q.cpu.a, 0x80); CHECK_EQ(FLAG(q.cpu, FLAG_C), 1); CHECK_EQ(FLAG(q.cpu, FLAG_N), 1);
    Sys m;  // memory forms
    m.mem[0x30] = 0x40; m.mem[0x1235] = 0x01; m.mem[0x31] = 0x01;
    m.prog({0x06, 0x30, 0x4E, 0x35, 0x12, 0x46, 0x31});
    CHECK_EQ(m.step(), 5); CHECK_EQ(m.mem[0x30], 0x80); CHECK_EQ(FLAG(m.cpu, FLAG_N), 1);
    CHECK_EQ(m.step(), 6); CHECK_EQ(m.mem[0x1235], 0x00); CHECK_EQ(FLAG(m.cpu, FLAG_C), 1);
    m.step(); CHECK_EQ(m.mem[0x31], 0x00);
    Sys i;
    i.mem[0x40] = 0xFF; i.mem[0x41] = 0x00;
    i.prog({0xE6, 0x40, 0xC6, 0x41, 0xE8, 0xC8, 0xCA, 0x88});
    i.step(); CHECK_EQ(i.mem[0x40], 0x00); CHECK_EQ(FLAG(i.cpu, FLAG_Z), 1);
    i.step(); CHECK_EQ(i.mem[0x41], 0xFF); CHECK_EQ(FLAG(i.cpu, FLAG_N), 1);
    i.run(2); CHECK_EQ(i.cpu.x, 1); CHECK_EQ(i.cpu.y, 1);
    i.run(2); CHECK_EQ(i.cpu.x, 0); CHECK_EQ(i.cpu.y, 0);
}

static void test_addressing() {
    Sys s;  // zero page,X wraps within page 0
    s.mem[0x01] = 0x77;
    s.prog({0xA2, 0x02, 0xB5, 0xFF});
    s.run(2); CHECK_EQ(s.cpu.a, 0x77);
    Sys y;  // zero page,Y (LDX) wraps
    y.mem[0x03] = 0x66;
    y.prog({0xA0, 0x04, 0xB6, 0xFF});
    y.run(2); CHECK_EQ(y.cpu.x, 0x66);
    Sys a;  // absolute,X: no page cross = 4, page cross = 5
    a.mem[0x1234 + 5] = 0x11; a.mem[0x12FE + 5] = 0x22;
    a.prog({0xA2, 0x05, 0xBD, 0x34, 0x12, 0xBD, 0xFE, 0x12});
    a.step(); CHECK_EQ(a.step(), 4); CHECK_EQ(a.cpu.a, 0x11);
    CHECK_EQ(a.step(), 5); CHECK_EQ(a.cpu.a, 0x22);
    Sys b;  // absolute,Y
    b.mem[0x2000] = 0x33;
    b.prog({0xA0, 0x01, 0xB9, 0xFF, 0x1F});
    b.step(); CHECK_EQ(b.step(), 5); CHECK_EQ(b.cpu.a, 0x33);
    Sys st;  // STA abs,X is always 5 cycles, no extra on cross
    st.prog({0xA2, 0x01, 0x9D, 0xFF, 0x12});
    st.step(); CHECK_EQ(st.step(), 5); CHECK_EQ(st.mem[0x1300], 0);
    Sys ix;  // (zp,X)
    ix.mem[0x24] = 0x00; ix.mem[0x25] = 0x30; ix.mem[0x3000] = 0x5A;
    ix.prog({0xA2, 0x04, 0xA1, 0x20});
    ix.step(); CHECK_EQ(ix.step(), 6); CHECK_EQ(ix.cpu.a, 0x5A);
    Sys iw;  // (zp,X) pointer high byte wraps in zero page
    iw.mem[0xFF] = 0x00; iw.mem[0x00] = 0x31; iw.mem[0x3100] = 0x6B;
    iw.prog({0xA2, 0x00, 0xA1, 0xFF});
    iw.run(2); CHECK_EQ(iw.cpu.a, 0x6B);
    Sys iy;  // (zp),Y with and without page cross
    iy.mem[0x40] = 0xF0; iy.mem[0x41] = 0x20; iy.mem[0x2105] = 0x7C; iy.mem[0x20F8] = 0x7D;
    iy.prog({0xA0, 0x08, 0xB1, 0x40, 0xA0, 0x15, 0xB1, 0x40});
    iy.step(); CHECK_EQ(iy.step(), 5); CHECK_EQ(iy.cpu.a, 0x7D);
    iy.step(); CHECK_EQ(iy.step(), 6);
    Sys j;  // JMP indirect and its page-wrap bug
    j.mem[0x0200] = 0x40; j.mem[0x02FF] = 0x00; j.mem[0x0300] = 0x99; j.mem[0x0100 + 0x00] = 0;
    j.prog({0x6C, 0xFF, 0x02});
    CHECK_EQ(j.step(), 5); CHECK_EQ(j.cpu.pc, 0x4000);  // high byte from 0x0200, not 0x0300
    Sys k;
    k.prog({0x4C, 0x00, 0x90});
    CHECK_EQ(k.step(), 3); CHECK_EQ(k.cpu.pc, 0x9000);
}

static void test_branches() {
    Sys s;  // BNE taken, same page: 3 cycles
    s.prog({0xD0, 0x05});
    CHECK_EQ(s.step(), 3); CHECK_EQ(s.cpu.pc, 0x8007);
    Sys n;  // not taken: 2 cycles
    n.prog({0xF0, 0x05});
    CHECK_EQ(n.step(), 2); CHECK_EQ(n.cpu.pc, 0x8002);
    Sys b;  // backward
    b.prog({0xD0, 0xFC});
    b.step(); CHECK_EQ(b.cpu.pc, 0x7FFE);
    Sys p;  // taken with page crossing: 4 cycles
    p.prog({0xD0, 0x7F}, 0x80F0);
    CHECK_EQ(p.step(), 4); CHECK_EQ(p.cpu.pc, 0x8171);
    Sys c;  // all eight conditions
    c.prog({0xB0, 0x10}); CHECK_EQ(c.step(), 2);  // BCS, C=0
    c.cpu.p |= Cpu6502::FLAG_C; c.prog({0xB0, 0x10}); CHECK_EQ(c.step(), 3);
    c.prog({0x90, 0x10}); CHECK_EQ(c.step(), 2);   // BCC, C=1
    c.cpu.p |= Cpu6502::FLAG_N; c.prog({0x30, 0x10}); CHECK_EQ(c.step(), 3);  // BMI
    c.prog({0x10, 0x10}); CHECK_EQ(c.step(), 2);   // BPL
    c.cpu.p |= Cpu6502::FLAG_V; c.prog({0x70, 0x10}); CHECK_EQ(c.step(), 3);  // BVS
    c.prog({0x50, 0x10}); CHECK_EQ(c.step(), 2);   // BVC
    c.cpu.p |= Cpu6502::FLAG_Z; c.prog({0xF0, 0x10}); CHECK_EQ(c.step(), 3);  // BEQ
    c.prog({0xD0, 0x10}); CHECK_EQ(c.step(), 2);   // BNE
}

static void test_stack() {
    Sys s;
    s.prog({0xA9, 0x42, 0x48, 0xA9, 0x00, 0x68});
    s.run(3); CHECK_EQ(s.cpu.sp, 0xFC); CHECK_EQ(s.mem[0x01FD], 0x42);
    s.step(); CHECK_EQ(s.cpu.a, 0x42); CHECK_EQ(s.cpu.sp, 0xFD);
    Sys f;  // PHP pushes B and U set; PLP ignores B, forces U
    f.prog({0x38, 0x08, 0x18, 0x28});
    f.run(2); CHECK_EQ(f.mem[0x01FD], 0x24 | 0x01 | 0x10);
    f.step(); CHECK_EQ(FLAG(f.cpu, FLAG_C), 0);
    f.step(); CHECK_EQ(FLAG(f.cpu, FLAG_C), 1); CHECK_EQ(f.cpu.p & 0x10, 0); CHECK_EQ(f.cpu.p & 0x20, 0x20);
    Sys j;  // JSR pushes return-1; RTS returns to next instruction
    j.prog({0x20, 0x00, 0x90, 0xEA});
    j.prog({0x60}, 0x9000);
    j.cpu.pc = 0x8000;
    CHECK_EQ(j.step(), 6); CHECK_EQ(j.cpu.pc, 0x9000);
    CHECK_EQ(j.mem[0x01FD], 0x80); CHECK_EQ(j.mem[0x01FC], 0x02); CHECK_EQ(j.cpu.sp, 0xFB);
    CHECK_EQ(j.step(), 6); CHECK_EQ(j.cpu.pc, 0x8003); CHECK_EQ(j.cpu.sp, 0xFD);
    Sys w;  // stack pointer wraps within page 1
    w.prog({0xA2, 0x00, 0x9A, 0xA9, 0x11, 0x48});
    w.run(4); CHECK_EQ(w.mem[0x0100], 0x11); CHECK_EQ(w.cpu.sp, 0xFF);
    Sys r;  // RTI
    r.mem[0x01FB] = 0x01 | 0x80; r.mem[0x01FC] = 0x34; r.mem[0x01FD] = 0x12; r.cpu.sp = 0xFA;
    r.prog({0x40});
    CHECK_EQ(r.step(), 6); CHECK_EQ(r.cpu.pc, 0x1234); CHECK_EQ(FLAG(r.cpu, FLAG_C), 1); CHECK_EQ(FLAG(r.cpu, FLAG_N), 1);
    CHECK_EQ(r.cpu.sp, 0xFD);
}

static void test_flag_instructions() {
    Sys s;
    s.prog({0x38, 0x78, 0xF8, 0x18, 0x58, 0xD8, 0xB8});
    s.cpu.p |= Cpu6502::FLAG_V;
    s.run(3); CHECK_EQ(FLAG(s.cpu, FLAG_C), 1); CHECK_EQ(FLAG(s.cpu, FLAG_I), 1); CHECK_EQ(FLAG(s.cpu, FLAG_D), 1);
    s.run(4); CHECK_EQ(FLAG(s.cpu, FLAG_C), 0); CHECK_EQ(FLAG(s.cpu, FLAG_I), 0);
    CHECK_EQ(FLAG(s.cpu, FLAG_D), 0); CHECK_EQ(FLAG(s.cpu, FLAG_V), 0);
}

static void test_interrupts() {
    Sys b;  // BRK
    b.prog({0x00, 0xFF});
    CHECK_EQ(b.step(), 7); CHECK_EQ(b.cpu.pc, 0xA000);
    CHECK_EQ(b.mem[0x01FD], 0x80); CHECK_EQ(b.mem[0x01FC], 0x02);  // PC+2
    CHECK_EQ(b.mem[0x01FB] & 0x30, 0x30); CHECK_EQ(FLAG(b.cpu, FLAG_I), 1); CHECK_EQ(b.cpu.sp, 0xFA);
    Sys n;  // NMI is non-maskable, pushes B clear
    n.prog({0xEA});
    n.mem[0x9000] = 0xEA;  // NOP at NMI handler
    n.cpu.nmi();
    CHECK_EQ(n.step(), 7); CHECK_EQ(n.cpu.pc, 0x9000);
    CHECK_EQ(n.mem[0x01FD], 0x80); CHECK_EQ(n.mem[0x01FC], 0x00);
    CHECK_EQ(n.mem[0x01FB] & 0x30, 0x20); CHECK_EQ(FLAG(n.cpu, FLAG_I), 1);
    CHECK_EQ(n.step(), 2);  // only serviced once
    Sys i;  // IRQ masked by I (set after reset), taken when cleared
    i.prog({0x58, 0xEA});
    i.cpu.setIrqLine(true);
    CHECK_EQ(i.step(), 2); CHECK_EQ(i.cpu.pc, 0x8001);  // CLI executed, IRQ was masked
    CHECK_EQ(i.step(), 7); CHECK_EQ(i.cpu.pc, 0xA000);
    CHECK_EQ(i.mem[0x01FB] & 0x30, 0x20);
    i.cpu.setIrqLine(false);
    Sys r;  // handler + RTI resumes
    r.prog({0xEA, 0xEA});
    r.prog({0xE8, 0x40}, 0x9000);
    r.cpu.pc = 0x8000;
    r.step(); r.cpu.nmi(); r.step(); r.step(); r.step();
    CHECK_EQ(r.cpu.x, 1); CHECK_EQ(r.cpu.pc, 0x8001);
    Sys d;  // DMA stall
    d.prog({0xEA});
    d.cpu.stall(513);
    CHECK_EQ(d.step(), 2 + 513);
}

static void test_program() {
    // Sum 1..10 with a loop and store the result (55) at $10.
    Sys t;
    t.prog({0xA2, 0x0A,        // LDX #10
            0xA9, 0x00,        // LDA #0
            0x86, 0x20,        // loop: STX $20
            0x18,              // CLC
            0x65, 0x20,        // ADC $20
            0xCA,              // DEX
            0xD0, 0xF8,        // BNE loop
            0x85, 0x10});      // STA $10
    for (int i = 0; i < 1000 && t.cpu.pc != 0x800E; i++) t.step();
    CHECK_EQ(t.mem[0x10], 55);
}

int main() {
    struct { const char* name; void (*fn)(); } tests[] = {
        {"reset", test_reset}, {"opcode_table", test_opcode_table},
        {"load_store_flags", test_load_store_flags}, {"arithmetic", test_arithmetic},
        {"logic_compare", test_logic_compare}, {"shifts_incdec", test_shifts_incdec},
        {"addressing", test_addressing}, {"branches", test_branches}, {"stack", test_stack},
        {"flag_instructions", test_flag_instructions}, {"interrupts", test_interrupts},
        {"program", test_program}};
    for (auto& t : tests) {
        int before = g_failed;
        t.fn();
        std::printf("[%s] %s\n", g_failed == before ? "PASS" : "FAIL", t.name);
    }
    std::printf("%d checks, %d failed\n", g_checks, g_failed);
    return g_failed ? 1 : 0;
}

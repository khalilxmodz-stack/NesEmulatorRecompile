#pragma once
// Ricoh 2A03 (6502 core, decimal mode disabled) - official opcodes only.
// Independent of Android; talks to memory through read/write callbacks.
#include <cstdint>

namespace nes {

class Cpu6502 {
public:
    using ReadFn = uint8_t (*)(void* ctx, uint16_t addr);
    using WriteFn = void (*)(void* ctx, uint16_t addr, uint8_t value);

    enum Flag : uint8_t {
        FLAG_C = 0x01, FLAG_Z = 0x02, FLAG_I = 0x04, FLAG_D = 0x08,
        FLAG_B = 0x10, FLAG_U = 0x20, FLAG_V = 0x40, FLAG_N = 0x80
    };

    Cpu6502(ReadFn read, WriteFn write, void* ctx);

    // Power-on/reset: A=X=Y=0, SP=0xFD, P=0x24, PC=[0xFFFC]; consumes 7 cycles.
    void reset();
    // Edge-triggered NMI request; serviced before the next instruction.
    void nmi();
    // Level-triggered IRQ line; serviced before the next instruction if I==0.
    void setIrqLine(bool asserted);
    // Add CPU stall cycles (e.g. OAM DMA); they are added to the next step().
    void stall(unsigned cycles);
    // Execute one instruction or one interrupt sequence; returns CPU cycles used.
    unsigned step();

    static unsigned officialOpcodeCount();
    static bool isOfficial(uint8_t opcode);

    uint8_t a = 0, x = 0, y = 0, sp = 0xFD, p = 0x24;
    uint16_t pc = 0;
    uint64_t totalCycles = 0;

    // Unofficial opcodes are NOT implemented: they execute as a 2-cycle,
    // 1-byte NOP and are counted here so callers can detect them.
    uint32_t illegalCount = 0;
    uint8_t lastIllegalOpcode = 0;

private:
    uint8_t rd(uint16_t addr) { return read_(ctx_, addr); }
    void wr(uint16_t addr, uint8_t v) { write_(ctx_, addr, v); }
    uint8_t fetch8() { return rd(pc++); }
    uint16_t fetch16();
    void push(uint8_t v) { wr(static_cast<uint16_t>(0x0100 | sp), v); sp--; }
    uint8_t pop() { sp++; return rd(static_cast<uint16_t>(0x0100 | sp)); }
    void push16(uint16_t v);
    uint16_t pop16();
    void setNZ(uint8_t v);
    void setFlag(uint8_t f, bool on) { p = on ? (p | f) : (p & ~f); }
    void adc(uint8_t m);
    void compare(uint8_t reg, uint8_t m);
    unsigned interrupt(uint16_t vector);

    ReadFn read_;
    WriteFn write_;
    void* ctx_;
    bool nmiPending_ = false;
    bool irqLine_ = false;
    unsigned pendingStall_ = 0;
};

}  // namespace nes

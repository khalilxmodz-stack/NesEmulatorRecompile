#include "cpu/cpu6502.h"

namespace nes {
namespace {

enum Op : uint8_t {
    ILL, ADC, AND, ASL, BCC, BCS, BEQ, BIT, BMI, BNE, BPL, BRK, BVC, BVS, CLC, CLD, CLI, CLV,
    CMP, CPX, CPY, DEC, DEX, DEY, EOR, INC, INX, INY, JMP, JSR, LDA, LDX, LDY, LSR, NOP, ORA,
    PHA, PHP, PLA, PLP, ROL, ROR, RTI, RTS, SBC, SEC, SED, SEI, STA, STX, STY, TAX, TAY, TSX,
    TXA, TXS, TYA
};
enum Mode : uint8_t { IMP, ACC, IMM, ZP, ZPX, ZPY, ABS, ABX, ABY, IND, IZX, IZY, REL };

struct Entry { Op op; Mode mode; uint8_t cycles; bool pageCross; };

struct Table {
    Entry e[256];
    unsigned count = 0;
    void s(uint8_t opc, Op op, Mode m, uint8_t cyc, bool px = false) {
        e[opc] = Entry{op, m, cyc, px};
    }
    // Standard 8-form group: imm, zp, zpx, abs, abx, aby, izx, izy
    void group(Op op, uint8_t base, bool store = false) {
        // base is the immediate opcode (x9); other forms at fixed offsets.
        if (!store) s(base, op, IMM, 2);
        s(static_cast<uint8_t>(base - 0x04), op, ZP, 3);
        s(static_cast<uint8_t>(base + 0x0C), op, ZPX, 4);
        s(static_cast<uint8_t>(base + 0x04), op, ABS, 4);
        s(static_cast<uint8_t>(base + 0x14), op, ABX, store ? 5 : 4, !store);
        s(static_cast<uint8_t>(base + 0x10), op, ABY, store ? 5 : 4, !store);
        s(static_cast<uint8_t>(base - 0x08), op, IZX, 6);
        s(static_cast<uint8_t>(base + 0x08), op, IZY, store ? 6 : 5, !store);
    }
    void shift(Op op, uint8_t acc) {  // acc = accumulator opcode (0A,2A,4A,6A)
        s(acc, op, ACC, 2);
        s(static_cast<uint8_t>(acc - 0x04), op, ZP, 5);
        s(static_cast<uint8_t>(acc + 0x0C), op, ZPX, 6);
        s(static_cast<uint8_t>(acc + 0x04), op, ABS, 6);
        s(static_cast<uint8_t>(acc + 0x14), op, ABX, 7);
    }
    Table() {
        for (auto& x : e) x = Entry{ILL, IMP, 2, false};
        group(ORA, 0x09); group(AND, 0x29); group(EOR, 0x49); group(ADC, 0x69);
        group(LDA, 0xA9); group(CMP, 0xC9); group(SBC, 0xE9);
        // STA: same layout as the groups above but no immediate form.
        group(STA, 0x89, true);
        e[0x89] = Entry{ILL, IMP, 2, false};  // 0x89 is not an official opcode
        shift(ASL, 0x0A); shift(ROL, 0x2A); shift(LSR, 0x4A); shift(ROR, 0x6A);
        s(0xC6, DEC, ZP, 5); s(0xD6, DEC, ZPX, 6); s(0xCE, DEC, ABS, 6); s(0xDE, DEC, ABX, 7);
        s(0xE6, INC, ZP, 5); s(0xF6, INC, ZPX, 6); s(0xEE, INC, ABS, 6); s(0xFE, INC, ABX, 7);
        s(0xA2, LDX, IMM, 2); s(0xA6, LDX, ZP, 3); s(0xB6, LDX, ZPY, 4); s(0xAE, LDX, ABS, 4);
        s(0xBE, LDX, ABY, 4, true);
        s(0xA0, LDY, IMM, 2); s(0xA4, LDY, ZP, 3); s(0xB4, LDY, ZPX, 4); s(0xAC, LDY, ABS, 4);
        s(0xBC, LDY, ABX, 4, true);
        s(0xE0, CPX, IMM, 2); s(0xE4, CPX, ZP, 3); s(0xEC, CPX, ABS, 4);
        s(0xC0, CPY, IMM, 2); s(0xC4, CPY, ZP, 3); s(0xCC, CPY, ABS, 4);
        s(0x86, STX, ZP, 3); s(0x96, STX, ZPY, 4); s(0x8E, STX, ABS, 4);
        s(0x84, STY, ZP, 3); s(0x94, STY, ZPX, 4); s(0x8C, STY, ABS, 4);
        s(0x24, BIT, ZP, 3); s(0x2C, BIT, ABS, 4);
        s(0x4C, JMP, ABS, 3); s(0x6C, JMP, IND, 5); s(0x20, JSR, ABS, 6);
        s(0x60, RTS, IMP, 6); s(0x40, RTI, IMP, 6); s(0x00, BRK, IMP, 7);
        s(0x10, BPL, REL, 2); s(0x30, BMI, REL, 2); s(0x50, BVC, REL, 2); s(0x70, BVS, REL, 2);
        s(0x90, BCC, REL, 2); s(0xB0, BCS, REL, 2); s(0xD0, BNE, REL, 2); s(0xF0, BEQ, REL, 2);
        s(0x18, CLC, IMP, 2); s(0x38, SEC, IMP, 2); s(0x58, CLI, IMP, 2); s(0x78, SEI, IMP, 2);
        s(0xB8, CLV, IMP, 2); s(0xD8, CLD, IMP, 2); s(0xF8, SED, IMP, 2);
        s(0xCA, DEX, IMP, 2); s(0x88, DEY, IMP, 2); s(0xE8, INX, IMP, 2); s(0xC8, INY, IMP, 2);
        s(0xEA, NOP, IMP, 2);
        s(0x48, PHA, IMP, 3); s(0x08, PHP, IMP, 3); s(0x68, PLA, IMP, 4); s(0x28, PLP, IMP, 4);
        s(0xAA, TAX, IMP, 2); s(0xA8, TAY, IMP, 2); s(0xBA, TSX, IMP, 2);
        s(0x8A, TXA, IMP, 2); s(0x9A, TXS, IMP, 2); s(0x98, TYA, IMP, 2);
        for (const auto& x : e) if (x.op != ILL) count++;
    }
};

const Table& table() {
    static const Table t;
    return t;
}

}  // namespace

Cpu6502::Cpu6502(ReadFn read, WriteFn write, void* ctx)
    : read_(read), write_(write), ctx_(ctx) {}

unsigned Cpu6502::officialOpcodeCount() { return table().count; }
bool Cpu6502::isOfficial(uint8_t opcode) { return table().e[opcode].op != ILL; }

uint16_t Cpu6502::fetch16() {
    uint16_t lo = fetch8();
    uint16_t hi = fetch8();
    return static_cast<uint16_t>(lo | (hi << 8));
}
void Cpu6502::push16(uint16_t v) {
    push(static_cast<uint8_t>(v >> 8));
    push(static_cast<uint8_t>(v & 0xFF));
}
uint16_t Cpu6502::pop16() {
    uint16_t lo = pop();
    uint16_t hi = pop();
    return static_cast<uint16_t>(lo | (hi << 8));
}
void Cpu6502::setNZ(uint8_t v) {
    setFlag(FLAG_Z, v == 0);
    setFlag(FLAG_N, (v & 0x80) != 0);
}

void Cpu6502::adc(uint8_t m) {  // decimal mode is not present on the 2A03
    unsigned sum = static_cast<unsigned>(a) + m + (p & FLAG_C ? 1u : 0u);
    uint8_t r = static_cast<uint8_t>(sum);
    setFlag(FLAG_C, sum > 0xFF);
    setFlag(FLAG_V, ((a ^ r) & (m ^ r) & 0x80) != 0);
    a = r;
    setNZ(a);
}
void Cpu6502::compare(uint8_t reg, uint8_t m) {
    setFlag(FLAG_C, reg >= m);
    setNZ(static_cast<uint8_t>(reg - m));
}

void Cpu6502::reset() {
    a = x = y = 0;
    sp = 0xFD;
    p = FLAG_U | FLAG_I;
    nmiPending_ = false;
    pendingStall_ = 0;
    uint16_t lo = rd(0xFFFC), hi = rd(0xFFFD);
    pc = static_cast<uint16_t>(lo | (hi << 8));
    totalCycles += 7;
}
void Cpu6502::nmi() { nmiPending_ = true; }
void Cpu6502::setIrqLine(bool asserted) { irqLine_ = asserted; }
void Cpu6502::stall(unsigned cycles) { pendingStall_ += cycles; }

unsigned Cpu6502::interrupt(uint16_t vector) {
    push16(pc);
    push(static_cast<uint8_t>((p & ~FLAG_B) | FLAG_U));
    setFlag(FLAG_I, true);
    uint16_t lo = rd(vector), hi = rd(static_cast<uint16_t>(vector + 1));
    pc = static_cast<uint16_t>(lo | (hi << 8));
    return 7;
}

unsigned Cpu6502::step() {
    unsigned extra = pendingStall_;
    pendingStall_ = 0;
    unsigned used;

    if (nmiPending_) {
        nmiPending_ = false;
        used = interrupt(0xFFFA);
    } else if (irqLine_ && !(p & FLAG_I)) {
        used = interrupt(0xFFFE);
    } else {
        const uint8_t opcode = fetch8();
        const Entry& e = table().e[opcode];
        used = e.cycles;
        if (e.op == ILL) {
            illegalCount++;
            lastIllegalOpcode = opcode;
        }

        uint16_t addr = 0;
        bool crossed = false;
        switch (e.mode) {
            case IMP: case ACC: break;
            case IMM: addr = pc++; break;
            case ZP: addr = fetch8(); break;
            case ZPX: addr = static_cast<uint8_t>(fetch8() + x); break;
            case ZPY: addr = static_cast<uint8_t>(fetch8() + y); break;
            case ABS: addr = fetch16(); break;
            case ABX: {
                uint16_t base = fetch16();
                addr = static_cast<uint16_t>(base + x);
                crossed = (base & 0xFF00) != (addr & 0xFF00);
                break;
            }
            case ABY: {
                uint16_t base = fetch16();
                addr = static_cast<uint16_t>(base + y);
                crossed = (base & 0xFF00) != (addr & 0xFF00);
                break;
            }
            case IND: {  // includes the 6502 page-wrap bug on the high byte
                uint16_t ptr = fetch16();
                uint16_t lo = rd(ptr);
                uint16_t hi = rd(static_cast<uint16_t>((ptr & 0xFF00) | ((ptr + 1) & 0x00FF)));
                addr = static_cast<uint16_t>(lo | (hi << 8));
                break;
            }
            case IZX: {
                uint8_t z = static_cast<uint8_t>(fetch8() + x);
                uint16_t lo = rd(z), hi = rd(static_cast<uint8_t>(z + 1));
                addr = static_cast<uint16_t>(lo | (hi << 8));
                break;
            }
            case IZY: {
                uint8_t z = fetch8();
                uint16_t lo = rd(z), hi = rd(static_cast<uint8_t>(z + 1));
                uint16_t base = static_cast<uint16_t>(lo | (hi << 8));
                addr = static_cast<uint16_t>(base + y);
                crossed = (base & 0xFF00) != (addr & 0xFF00);
                break;
            }
            case REL: {
                int8_t off = static_cast<int8_t>(fetch8());
                addr = static_cast<uint16_t>(pc + off);
                break;
            }
        }
        if (e.pageCross && crossed) used++;

        const bool acc = (e.mode == ACC);
        auto branch = [&](bool cond) {
            if (cond) {
                used++;
                if ((pc & 0xFF00) != (addr & 0xFF00)) used++;
                pc = addr;
            }
        };
        uint8_t v;
        switch (e.op) {
            case ILL: case NOP: break;
            case LDA: a = rd(addr); setNZ(a); break;
            case LDX: x = rd(addr); setNZ(x); break;
            case LDY: y = rd(addr); setNZ(y); break;
            case STA: wr(addr, a); break;
            case STX: wr(addr, x); break;
            case STY: wr(addr, y); break;
            case TAX: x = a; setNZ(x); break;
            case TAY: y = a; setNZ(y); break;
            case TXA: a = x; setNZ(a); break;
            case TYA: a = y; setNZ(a); break;
            case TSX: x = sp; setNZ(x); break;
            case TXS: sp = x; break;
            case PHA: push(a); break;
            case PHP: push(p | FLAG_B | FLAG_U); break;
            case PLA: a = pop(); setNZ(a); break;
            case PLP: p = static_cast<uint8_t>((pop() & ~FLAG_B) | FLAG_U); break;
            case AND: a &= rd(addr); setNZ(a); break;
            case ORA: a |= rd(addr); setNZ(a); break;
            case EOR: a ^= rd(addr); setNZ(a); break;
            case ADC: adc(rd(addr)); break;
            case SBC: adc(static_cast<uint8_t>(~rd(addr))); break;
            case CMP: compare(a, rd(addr)); break;
            case CPX: compare(x, rd(addr)); break;
            case CPY: compare(y, rd(addr)); break;
            case BIT:
                v = rd(addr);
                setFlag(FLAG_Z, (a & v) == 0);
                setFlag(FLAG_N, (v & 0x80) != 0);
                setFlag(FLAG_V, (v & 0x40) != 0);
                break;
            case INC: v = static_cast<uint8_t>(rd(addr) + 1); wr(addr, v); setNZ(v); break;
            case DEC: v = static_cast<uint8_t>(rd(addr) - 1); wr(addr, v); setNZ(v); break;
            case INX: x++; setNZ(x); break;
            case INY: y++; setNZ(y); break;
            case DEX: x--; setNZ(x); break;
            case DEY: y--; setNZ(y); break;
            case ASL:
                v = acc ? a : rd(addr);
                setFlag(FLAG_C, (v & 0x80) != 0);
                v = static_cast<uint8_t>(v << 1);
                setNZ(v);
                if (acc) a = v; else wr(addr, v);
                break;
            case LSR:
                v = acc ? a : rd(addr);
                setFlag(FLAG_C, (v & 0x01) != 0);
                v = static_cast<uint8_t>(v >> 1);
                setNZ(v);
                if (acc) a = v; else wr(addr, v);
                break;
            case ROL: {
                v = acc ? a : rd(addr);
                uint8_t cin = (p & FLAG_C) ? 1 : 0;
                setFlag(FLAG_C, (v & 0x80) != 0);
                v = static_cast<uint8_t>((v << 1) | cin);
                setNZ(v);
                if (acc) a = v; else wr(addr, v);
                break;
            }
            case ROR: {
                v = acc ? a : rd(addr);
                uint8_t cin = (p & FLAG_C) ? 0x80 : 0;
                setFlag(FLAG_C, (v & 0x01) != 0);
                v = static_cast<uint8_t>((v >> 1) | cin);
                setNZ(v);
                if (acc) a = v; else wr(addr, v);
                break;
            }
            case JMP: pc = addr; break;
            case JSR: push16(static_cast<uint16_t>(pc - 1)); pc = addr; break;
            case RTS: pc = static_cast<uint16_t>(pop16() + 1); break;
            case RTI:
                p = static_cast<uint8_t>((pop() & ~FLAG_B) | FLAG_U);
                pc = pop16();
                break;
            case BRK: {
                push16(static_cast<uint16_t>(pc + 1));  // skip padding byte
                push(p | FLAG_B | FLAG_U);
                setFlag(FLAG_I, true);
                uint16_t lo = rd(0xFFFE), hi = rd(0xFFFF);
                pc = static_cast<uint16_t>(lo | (hi << 8));
                break;
            }
            case BCC: branch(!(p & FLAG_C)); break;
            case BCS: branch(p & FLAG_C); break;
            case BNE: branch(!(p & FLAG_Z)); break;
            case BEQ: branch(p & FLAG_Z); break;
            case BPL: branch(!(p & FLAG_N)); break;
            case BMI: branch(p & FLAG_N); break;
            case BVC: branch(!(p & FLAG_V)); break;
            case BVS: branch(p & FLAG_V); break;
            case CLC: setFlag(FLAG_C, false); break;
            case SEC: setFlag(FLAG_C, true); break;
            case CLI: setFlag(FLAG_I, false); break;
            case SEI: setFlag(FLAG_I, true); break;
            case CLD: setFlag(FLAG_D, false); break;
            case SED: setFlag(FLAG_D, true); break;
            case CLV: setFlag(FLAG_V, false); break;
        }
    }
    used += extra;
    totalCycles += used;
    return used;
}

}  // namespace nes

#pragma once
namespace nes {
const char* coreVersion();
int pointerSizeBits();
// Number of official 6502 opcodes implemented by the CPU core.
unsigned cpuOfficialOpcodeCount();
}

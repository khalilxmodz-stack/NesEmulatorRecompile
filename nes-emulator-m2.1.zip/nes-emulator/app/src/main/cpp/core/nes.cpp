#include "core/nes.h"
#include "cpu/cpu6502.h"
namespace nes {
const char* coreVersion() { return "0.2.0-m2 (CPU only; no PPU/APU/cartridge yet)"; }
int pointerSizeBits() { return static_cast<int>(sizeof(void*) * 8); }
unsigned cpuOfficialOpcodeCount() { return Cpu6502::officialOpcodeCount(); }
}
